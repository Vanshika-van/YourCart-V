import React, { createContext, useState } from "react";

// Create the context
 export const authDataContext = createContext();

// Context provider component
export const AuthContextProvider = ({ children, value }) => {
  const [userData, setUserData] = useState(null);

  return (
    <authDataContext.Provider value={{ userData, setUserData, ...value }}>
      {children}
    </authDataContext.Provider>
  );
};
