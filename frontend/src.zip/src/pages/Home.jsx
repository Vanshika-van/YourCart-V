import Background from "../component/Background";
import { Hero } from "../component/Hero";
import React, { useState } from "react";


function Home() {
  let heroData=[
     {text1:"30% OFF Limited Offer",text2:"Style that "},
     {text1:"Discover the Best of Bold Fashion",text2:"Limited Time Only!"},
     {text1:"Explore Our Best Collection",text2:"Shop Now!"},
     {text1:"Choose your Perfect Fashion Fit",text2:"Now on Sale!"}
  ]

  let [heroCount,setHeroCount]=useState(0);
  return (
    <div className="w-[100vw] h-[100vh] bg-gradient-to-br from-[#141414] to-[#0c2025] overflow-hidden">
      <div className="flex w-full h-full">
        {/* LEFT - Hero Text */}
        <div className="w-1/2 flex items-start justify-start pt-30 pl-10">
          <Hero
            heroCount={heroCount}
            setHeroCount={setHeroCount}
            heroData={heroData[heroCount % heroData.length]}
          />
        </div>

        {/* RIGHT - Image / Background */}
        <div className="w-1/2 relative overflow-hidden">
          <Background heroCount={heroCount} />
        </div>
      </div>
    </div>
  )
}

export default Home
